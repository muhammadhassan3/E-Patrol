package com.muhammhassan.jkblc_starter_project.core.api

interface NewsEndpoint {
    //TODO 7 : Definisikan Endpoint yang digunakan
}