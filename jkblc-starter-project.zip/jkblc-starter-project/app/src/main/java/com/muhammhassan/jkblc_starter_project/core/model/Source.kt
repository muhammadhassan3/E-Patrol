package com.muhammhassan.jkblc_starter_project.core.model

data class Source(
    val id: String,
    val name: String
)