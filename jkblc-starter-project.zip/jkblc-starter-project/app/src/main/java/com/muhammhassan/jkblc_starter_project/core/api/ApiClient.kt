package com.muhammhassan.jkblc_starter_project.core.api

class ApiClient {
    companion object{
        private var INSTANCE: NewsEndpoint? = null

        //TODO 6 : Inisiasi object retrofit
        fun getInstance(){
        }
    }
}